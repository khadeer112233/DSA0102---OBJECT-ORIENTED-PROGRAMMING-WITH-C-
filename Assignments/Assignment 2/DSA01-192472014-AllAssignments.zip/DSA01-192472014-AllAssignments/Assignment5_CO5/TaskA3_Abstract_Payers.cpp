#include <iostream>
#include <algorithm>
class Bill{double amount;public:explicit Bill(double a):amount(a){if(a<0)throw std::invalid_argument("negative bill");}double total()const{return amount;}};
class Payer{public:virtual double amountCovered(const Bill&)const=0;virtual~Payer()=default;};
class SelfPay:public Payer{public:double amountCovered(const Bill&b)const override{return b.total();}};
class Insurance:public Payer{double limit,copay;public:Insurance(double l,double c):limit(l),copay(c){}double amountCovered(const Bill&b)const override{return std::min(limit,b.total()*(1-copay/100));}};
class GovernmentScheme:public Payer{double package;public:explicit GovernmentScheme(double p):package(p){}double amountCovered(const Bill&b)const override{return std::min(package,b.total());}};
class Corporate:public Payer{double percent;public:explicit Corporate(double p):percent(p){}double amountCovered(const Bill&b)const override{return b.total()*percent/100;}};
int main(){Bill b(10000);SelfPay s;Insurance i(8000,20);GovernmentScheme g(6000);Corporate c(90);std::cout<<s.amountCovered(b)<<' '<<i.amountCovered(b)<<' '<<g.amountCovered(b)<<' '<<c.amountCovered(b)<<'\n';}
