#include <iostream>
#include <memory>
#include <vector>
class Bill{public:virtual double total()const=0;virtual std::string type()const=0;virtual~Bill()=default;};
class OutPatientBill:public Bill{double consult,tests;public:OutPatientBill(double c,double t):consult(c),tests(t){}double total()const override{return consult+tests;}std::string type()const override{return "OP";}};
class InPatientBill:public Bill{double room,procedure,medicine;int days;public:InPatientBill(double r,int d,double p,double m):room(r),procedure(p),medicine(m),days(d){}double total()const override{return room*days+procedure+medicine;}std::string type()const override{return "IP";}};
class DayCareBill:public Bill{double package;public:explicit DayCareBill(double p):package(p){}double total()const override{return package;}std::string type()const override{return "DayCare";}};
class EmergencyBill:public Bill{double base,perHour;int hours;public:EmergencyBill(double b,double r,int h):base(b),perHour(r),hours(h){}double total()const override{return base+perHour*hours;}std::string type()const override{return "Emergency";}};
int main(){std::vector<std::unique_ptr<Bill>> bills;bills.push_back(std::make_unique<OutPatientBill>(500,700));bills.push_back(std::make_unique<InPatientBill>(1000,2,3000,800));bills.push_back(std::make_unique<DayCareBill>(6500));bills.push_back(std::make_unique<EmergencyBill>(1000,250,3));double sum=0;for(auto&b:bills){std::cout<<b->type()<<": "<<b->total()<<'\n';sum+=b->total();}std::cout<<"Daily total: "<<sum<<'\n';}
