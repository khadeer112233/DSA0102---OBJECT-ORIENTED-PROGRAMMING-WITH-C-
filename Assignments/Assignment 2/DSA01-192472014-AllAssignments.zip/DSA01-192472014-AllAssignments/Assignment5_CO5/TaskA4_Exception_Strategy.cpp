#include <iostream>
#include <stdexcept>
class BillingError:public std::runtime_error{public:using std::runtime_error::runtime_error;};
class ClaimError:public BillingError{public:using BillingError::BillingError;};
double validateCharge(double x){if(x<0)throw BillingError("Negative charge");return x;}
int main(){for(double x:{500.0,-10.0})try{std::cout<<"Charge "<<validateCharge(x)<<'\n';}catch(const BillingError&e){std::cout<<"Rejected: "<<e.what()<<'\n';}}
