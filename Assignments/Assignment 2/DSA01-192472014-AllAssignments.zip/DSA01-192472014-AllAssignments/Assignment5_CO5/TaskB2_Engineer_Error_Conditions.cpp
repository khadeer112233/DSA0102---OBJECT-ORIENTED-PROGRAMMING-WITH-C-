#include <iostream>
#include <stdexcept>
#include <memory>
double parseAmount(const std::string&s){size_t n=0;double x=std::stod(s,&n);if(n!=s.size()||x<0)throw std::invalid_argument("invalid amount");return x;}
struct Resource{~Resource(){std::cout<<"resource released\n";}};
int main(){for(std::string s:{"250.50","-5","abc"}){try{auto r=std::make_unique<Resource>();std::cout<<"Accepted "<<parseAmount(s)<<'\n';}catch(const std::exception&e){std::cout<<"Rejected: "<<e.what()<<'\n';}catch(...){std::cout<<"Unknown error\n";}}}
