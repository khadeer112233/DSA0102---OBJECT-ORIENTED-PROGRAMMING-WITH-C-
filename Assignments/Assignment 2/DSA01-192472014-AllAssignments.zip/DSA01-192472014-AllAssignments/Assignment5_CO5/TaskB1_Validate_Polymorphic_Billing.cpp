#include <iostream>
#include <memory>
#include <vector>
struct Bill{virtual double total()const=0;virtual~Bill()=default;};
struct OP:Bill{double c,t;OP(double a,double b):c(a),t(b){}double total()const override{return c+t;}};
struct IP:Bill{double room,procedure;int days;IP(double r,int d,double p):room(r),procedure(p),days(d){}double total()const override{return room*days+procedure;}};
int main(){std::vector<std::unique_ptr<Bill>> v;v.push_back(std::make_unique<OP>(500,200));v.push_back(std::make_unique<IP>(1000,3,2000));for(auto&b:v)std::cout<<b->total()<<'\n';}
