#include <iostream>
#include <vector>
#include <chrono>
#include <memory>
struct Base{virtual long long total()const=0;virtual~Base()=default;};
struct A:Base{long long x;A(long long v):x(v){}long long total()const override{return x;}};
struct Plain{int type;long long x;};
int main(){constexpr int N=1000000;std::vector<std::unique_ptr<Base>> v;std::vector<Plain> p;v.reserve(N);p.reserve(N);for(int i=0;i<N;++i){v.push_back(std::make_unique<A>(i%100));p.push_back({0,i%100});}volatile long long sum1=0,sum2=0;auto t1=std::chrono::steady_clock::now();for(auto&x:v)sum1+=x->total();auto t2=std::chrono::steady_clock::now();for(auto&x:p){switch(x.type){case 0:sum2+=x.x;break;}}auto t3=std::chrono::steady_clock::now();std::cout<<"Virtual sum "<<sum1<<" time "<<std::chrono::duration<double>(t2-t1).count()<<" s\n";std::cout<<"Switch sum "<<sum2<<" time "<<std::chrono::duration<double>(t3-t2).count()<<" s\n";}
