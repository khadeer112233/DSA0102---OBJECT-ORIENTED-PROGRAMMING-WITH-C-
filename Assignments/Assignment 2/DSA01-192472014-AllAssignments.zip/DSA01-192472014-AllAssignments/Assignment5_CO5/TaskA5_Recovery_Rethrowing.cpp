#include <iostream>
#include <string>
struct Guard{std::string n;explicit Guard(std::string s):n(std::move(s)){}~Guard(){std::cout<<'~'<<n<<' ';}};
void process(){Guard g("process");try{throw 42;}catch(int){std::cout<<"logged ";throw;}}
int main(){Guard mainGuard("main");try{process();}catch(int x){std::cout<<"caught "<<x;}std::cout<<'\n';}
