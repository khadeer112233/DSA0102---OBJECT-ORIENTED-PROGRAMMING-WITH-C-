#include <iostream>
#include <memory>
#include <vector>
class Bill{public:virtual double total()const=0;virtual~Bill()=default;};
class OP:public Bill{double x;public:explicit OP(double a):x(a){}double total()const override{return x;}};
class Maternity:public Bill{double package;public:explicit Maternity(double p):package(p){}double total()const override{return package;}};
class Payer{public:virtual double cover(double amount)const=0;virtual~Payer()=default;};
class CorporatePayer:public Payer{double rate;public:explicit CorporatePayer(double r):rate(r){}double cover(double a)const override{return a*rate/100;}};
int main(){std::vector<std::unique_ptr<Bill>> bills;bills.push_back(std::make_unique<OP>(1500));bills.push_back(std::make_unique<Maternity>(25000));CorporatePayer payer(90);for(auto&b:bills)std::cout<<"Bill "<<b->total()<<" covered "<<payer.cover(b->total())<<'\n';}
