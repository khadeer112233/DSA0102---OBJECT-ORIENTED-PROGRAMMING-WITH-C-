# Assignment5_CO5

Each `.cpp` file is a standalone C++17 program. Compile and run from this folder:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic TaskFile.cpp -o app
./app
```

Replace `TaskFile.cpp` with the required filename. The source files demonstrate the implementation concepts for the corresponding assignment tasks.
