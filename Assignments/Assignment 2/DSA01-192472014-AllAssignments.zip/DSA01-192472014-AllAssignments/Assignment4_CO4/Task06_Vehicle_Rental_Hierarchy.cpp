#include <iostream>
#include <memory>
#include <vector>
class Vehicle{protected:std::string reg;double rate;public:Vehicle(std::string r,double d):reg(r),rate(d){}virtual double charge(int days)const=0;virtual void info()const{std::cout<<reg<<" ";}virtual~Vehicle()=default;};
class Bicycle:public Vehicle{public:using Vehicle::Vehicle;double charge(int d)const override{return rate*d;}};
class TwoWheeler:public Vehicle{public:using Vehicle::Vehicle;double charge(int d)const override{return rate*d+50;}};
class Car:public Vehicle{int seats;public:Car(std::string r,double d,int s):Vehicle(r,d),seats(s){}double charge(int d)const override{return rate*d+seats*10;}};
class ElectricCar:public Car{double kwh;public:ElectricCar(std::string r,double d,int s,double k):Car(r,d,s),kwh(k){}double charge(int d)const override{return Car::charge(d)+kwh*8;}};
int main(){std::vector<std::unique_ptr<Vehicle>> fleet;fleet.push_back(std::make_unique<Bicycle>("BIKE1",100));fleet.push_back(std::make_unique<TwoWheeler>("TW1",250));fleet.push_back(std::make_unique<Car>("CAR1",1000,5));fleet.push_back(std::make_unique<ElectricCar>("EV1",1200,5,30));for(auto&v:fleet)std::cout<<v->charge(2)<<'\n';}
