#include <iostream>
struct Person{std::string name;Person(std::string n="Person"):name(n){std::cout<<"Person ";}};
struct Student:virtual Person{Student(std::string n="Student"):Person(n){std::cout<<"Student ";}};
struct Staff:virtual Person{Staff(std::string n="Staff"):Person(n){std::cout<<"Staff ";}};
struct TeachingAssistant:Student,Staff{TeachingAssistant(std::string n):Person(n),Student(n),Staff(n){std::cout<<"TA ";}};
struct ResearchScholar:Student{using Student::Student;};
int main(){TeachingAssistant t("Kavya");std::cout<<t.name<<'\n';}
