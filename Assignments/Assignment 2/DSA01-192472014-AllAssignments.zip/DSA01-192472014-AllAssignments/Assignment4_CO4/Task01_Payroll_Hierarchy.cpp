#include <iostream>
#include <memory>
#include <vector>
class Staff{protected:std::string name;double basic;public:Staff(std::string n,double b):name(n),basic(b){}virtual double pay()const=0;virtual ~Staff()=default;};
class Professor:public Staff{double research;public:Professor(std::string n,double b,double r):Staff(n,b),research(r){}double pay()const override{return basic*1.42+research;}};
class LabAssistant:public Staff{public:using Staff::Staff;double pay()const override{return basic*1.42;}};
class GuestFaculty:public Staff{double hours,rate;public:GuestFaculty(std::string n,double h,double r):Staff(n,0),hours(h),rate(r){}double pay()const override{return hours*rate;}};
int main(){std::vector<std::unique_ptr<Staff>> v;v.push_back(std::make_unique<Professor>("Anu",50000,5000));v.push_back(std::make_unique<LabAssistant>("Bala",30000));v.push_back(std::make_unique<GuestFaculty>("Chetan",20,1000));for(auto&s:v)std::cout<<s->pay()<<'\n';}
