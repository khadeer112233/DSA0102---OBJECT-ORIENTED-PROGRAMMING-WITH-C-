#include <iostream>
#include <vector>
class Cart{std::string owner;double total=0;public:Cart(std::string n):owner(n){}Cart&add(double price){total+=price;return *this;}double getTotal()const{return total;}const std::string&getOwner()const{return owner;}};
int main(){Cart a("Asha");a.add(100).add(50);Cart* p=&a;Cart& r=a;std::cout<<a.getTotal()<<' '<<p->getTotal()<<' '<<r.getTotal()<<'\n';Cart* heap=new Cart("Bala");heap->add(300);std::cout<<heap->getTotal()<<'\n';delete heap;Cart c[2]={{"C1"},{"C2"}};c[0].add(10);c[1].add(20);Cart* best=c[0].getTotal()>c[1].getTotal()?&c[0]:&c[1];std::cout<<best->getOwner()<<'\n';}
