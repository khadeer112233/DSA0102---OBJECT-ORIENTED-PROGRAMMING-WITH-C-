#include <iostream>
class Account{public:virtual double rate()const{return 3.5;}virtual~Account(){std::cout<<"Account released\n";}};
class SeniorAccount:public Account{double* history=new double[100];public:double rate()const override{return 4.0;}~SeniorAccount()override{delete[]history;std::cout<<"Senior history released\n";}};
int main(){Account* a=new SeniorAccount;std::cout<<a->rate()<<"%\n";delete a;}
