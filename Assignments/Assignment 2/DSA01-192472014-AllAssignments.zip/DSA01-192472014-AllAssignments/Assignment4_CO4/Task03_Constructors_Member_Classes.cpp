#include <iostream>
#include <string>
class Address{std::string city;int pin;public:Address(std::string c,int p):city(c),pin(p){}std::string str()const{return city+"-"+std::to_string(pin);}};
class Person{protected:std::string name;int age;Address address;public:Person(std::string n,int a,std::string c,int p):name(n),age(a),address(c,p){std::cout<<"Person constructed\n";}virtual~Person(){std::cout<<"Person destroyed\n";}};
class Student:public Person{long long reg;public:Student(std::string n,int a,long long r,std::string c,int p):Person(n,a,c,p),reg(r){std::cout<<"Student constructed\n";}~Student(){std::cout<<"Student destroyed\n";}void print()const{std::cout<<reg<<' '<<name<<" ("<<age<<") "<<address.str()<<'\n';}};
int main(){Student s("Kavya",19,192311001,"Salem",636001);s.print();}
