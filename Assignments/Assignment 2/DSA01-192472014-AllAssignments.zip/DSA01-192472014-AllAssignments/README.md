# DSA01 – C++ Assignments 1–5

**Student:** SD Khadeer  
**Register number:** 192472014  
**Language:** C++17  
**Compiler:** g++ (record the installed version using `g++ --version`)

This repository combines the runnable code examples for all five uploaded OOP with C++ assignments.

## Folder structure

- `Assignment1_CO1` – fare logic, C++ tokens/constants, data types, conversions, operators, control structures and smart-card design (Tasks 1–12).
- `Assignment2_CO2` – functions, references, overloading, classes, arrays, static/friend/inline members and redesign (Q1–Q7).
- `Assignment3_CO3` – constructors, deep copy, dynamic memory, destructors and operator overloading (Q1–Q7).
- `Assignment4_CO4` – inheritance, virtual bases, construction order, object pointers, `this`, and vehicle hierarchy (Tasks 1–6).
- `Assignment5_CO5` – polymorphic bills, abstract payers, exceptions, recovery, validation, benchmarking and extension (A1–A5, B1–B4).

## Compile and run

Compile any source file independently:

```bash
g++ -std=c++17 -Wall -Wextra -pedantic path/to/TaskFile.cpp -o app
./app
```

On Windows PowerShell:

```powershell
g++ -std=c++17 -Wall -Wextra -pedantic .\TaskFile.cpp -o app.exe
.\app.exe
```

For memory checking (where supported):

```bash
g++ -std=c++17 -Wall -Wextra -g -fsanitize=address -fno-omit-frame-pointer TaskFile.cpp -o app
./app
```

For the Assignment 5 timing comparison, use optimisation:

```bash
g++ -std=c++17 -O2 -Wall -Wextra TaskB3_Performance_Comparison.cpp -o benchmark
./benchmark
```

## Important notes

1. Every `.cpp` file has its own `main()` and must be compiled separately; do not compile all files into one executable.
2. The programs are implementation examples for the programming portions of the uploaded PDFs. Some assignment questions are primarily written analysis/UML/pseudocode tasks and therefore are represented by a small runnable demonstration rather than a complete written report.
3. Run each program on your own compiler and capture your own output screenshots. The benchmark timings depend on the computer and compiler.
4. Before submission, verify all task requirements against the PDFs, add any requested experimental evidence, and commit each task separately to GitHub.
5. Repository name suggestion: `DSA01-192472014-AllAssignments`.
