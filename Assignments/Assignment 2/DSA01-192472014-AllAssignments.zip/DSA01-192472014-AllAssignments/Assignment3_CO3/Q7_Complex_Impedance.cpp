#include <iostream>
#include <cmath>
#include <stdexcept>
class Complex{double re,im;public:Complex():re(0),im(0){}Complex(double r):re(r),im(0){}Complex(double r,double i):re(r),im(i){}Complex operator+(Complex z)const{return {re+z.re,im+z.im};}Complex operator*(Complex z)const{return {re*z.re-im*z.im,re*z.im+im*z.re};}Complex operator/(Complex z)const{double d=z.re*z.re+z.im*z.im;if(d==0)throw std::domain_error("division by zero");return {(re*z.re+im*z.im)/d,(im*z.re-re*z.im)/d};}double magnitude()const{return std::hypot(re,im);}void print()const{std::cout<<re<<(im<0?" - j":" + j")<<std::abs(im);}};
int main(){try{Complex resistor(10),inductor(0,5);Complex series=resistor+inductor;std::cout<<"Series: ";series.print();std::cout<<" |Z|="<<series.magnitude()<<"\n";Complex parallel=(resistor*inductor)/(resistor+inductor);std::cout<<"Parallel: ";parallel.print();std::cout<<'\n';}catch(const std::exception&e){std::cout<<e.what()<<'\n';}}
