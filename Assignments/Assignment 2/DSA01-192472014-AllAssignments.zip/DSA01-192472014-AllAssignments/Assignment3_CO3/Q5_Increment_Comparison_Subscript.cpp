#include <iostream>
#include <vector>
#include <stdexcept>
class Time{int sec;public:explicit Time(int s=0):sec(s){}Time&operator++(){++sec;return *this;}Time operator++(int){Time old=*this;++sec;return old;}friend bool operator==(Time a,Time b){return a.sec==b.sec;}friend bool operator<(Time a,Time b){return a.sec<b.sec;}int value()const{return sec;}};
class Playlist{std::vector<std::string> tracks;public:Playlist():tracks{"Intro","Song A","Song B"}{}std::string&operator[](size_t i){if(i>=tracks.size())throw std::out_of_range("track");return tracks[i];}const std::string&operator[](size_t i)const{if(i>=tracks.size())throw std::out_of_range("track");return tracks[i];}};
int main(){Time t(0);std::cout<<t++.value()<<' '<<(++t).value()<<'\n';Playlist p;std::cout<<p[1]<<'\n';}
