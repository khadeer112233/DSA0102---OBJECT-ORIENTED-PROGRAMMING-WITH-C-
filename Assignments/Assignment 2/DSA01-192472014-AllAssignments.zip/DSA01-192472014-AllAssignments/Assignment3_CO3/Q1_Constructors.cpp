#include <iostream>
#include <string>
#include <stdexcept>
class Book{std::string title,author;int copies;public:Book():Book("Untitled","Unknown",0){}Book(std::string t):Book(t,"Donated",1){}Book(std::string t,std::string a,int c):title(std::move(t)),author(std::move(a)),copies(c){if(c<0)throw std::invalid_argument("negative copies");}void show()const{std::cout<<title<<" | "<<author<<" | "<<copies<<'\n';}};
int main(){Book a,b("C++ Basics"),c("OOP","K. Rao",5);a.show();b.show();c.show();}
