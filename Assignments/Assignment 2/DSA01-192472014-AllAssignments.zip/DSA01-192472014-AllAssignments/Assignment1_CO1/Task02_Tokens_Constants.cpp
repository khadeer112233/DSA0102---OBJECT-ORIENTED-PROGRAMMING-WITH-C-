#include <iostream>
enum class Zone { Inner, Middle, Outer };
constexpr int INNER_FARE=1000, MIDDLE_FARE=2000, OUTER_FARE=3000;
constexpr int PEAK_PERCENT=20;
int main(){ Zone z=Zone::Middle; int fare=(z==Zone::Inner?INNER_FARE:z==Zone::Middle?MIDDLE_FARE:OUTER_FARE); std::cout<<"Fare in paise: "<<fare<<"\nPeak fare: "<<fare+fare*PEAK_PERCENT/100<<"\n"; }
