#include <iostream>
#include <string>
class SmartCard { long long paise; public: explicit SmartCard(long long p):paise(p){} bool pay(long long f){if(paise-f<5000)return false;paise-=f;return true;} long long balance()const{return paise;} };
int main(){ int zone=2,hour=18; bool student=true; long long fare=(zone==1?1000:zone==2?2000:zone==3?3000:0); if((hour>=8&&hour<10)||(hour>=17&&hour<20)) fare+=fare*20/100; if(student)fare-=fare*10/100; SmartCard card(10000); std::cout<<"Fare: Rs "<<fare/100.0<<"\n"<<(card.pay(fare)?"Accepted":"Rejected")<<"\nRemaining: Rs "<<card.balance()/100.0<<"\n"; }
