#include <iostream>
#include <string>
using namespace std;
class SmartCard { long long paise; public: SmartCard(long long p):paise(p){} bool debit(long long fare){ if(paise-fare<5000) return false; paise-=fare; return true;} long long balance()const{return paise;} };
class Passenger { string name, category; public: Passenger(string n,string c):name(n),category(c){} int discount()const{return category=="Student"||category=="Senior"?10:0;} };
int main(){ Passenger p("Asha","Student"); SmartCard c(10000); long long fare=2000-(2000*p.discount()/100); cout<<"Passenger concession: "<<p.discount()<<"%\n"; cout<<(c.debit(fare)?"Journey allowed":"Insufficient balance")<<"\nBalance: Rs "<<c.balance()/100.0<<"\n"; }
