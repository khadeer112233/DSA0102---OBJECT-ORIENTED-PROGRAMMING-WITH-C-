#include <iostream>
#include <vector>
class FarePolicy { public: virtual long long fare(int zone,bool peak,bool concession)const=0; virtual ~FarePolicy()=default; };
class StandardPolicy:public FarePolicy{public:long long fare(int z,bool p,bool c)const override{long long f=z*1000LL;if(p)f+=f/5;if(c)f-=f/10;return f;}};
int main(){ StandardPolicy policy; std::cout<<"Final fare (paise): "<<policy.fare(2,true,false)<<"\n"; }
