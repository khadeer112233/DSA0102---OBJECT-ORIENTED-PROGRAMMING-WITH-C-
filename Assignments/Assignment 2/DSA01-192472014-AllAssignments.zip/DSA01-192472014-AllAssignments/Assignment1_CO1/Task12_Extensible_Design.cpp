#include <iostream>
enum class Zone{Inner=1,Middle=2,Outer=3,Airport=4};
constexpr long long fares[]={0,1000,2000,3000,4500};
long long compute(Zone z,bool weekend,bool peak){auto f=fares[static_cast<int>(z)];if(peak)f+=f/5;if(weekend)f-=f/10;return f;}
int main(){std::cout<<"Weekend airport fare (paise): "<<compute(Zone::Airport,true,false)<<"\n";}
