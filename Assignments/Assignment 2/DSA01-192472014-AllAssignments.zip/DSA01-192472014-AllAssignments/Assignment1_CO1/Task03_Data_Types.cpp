#include <iostream>
#include <climits>
#include <limits>
int main(){ long long balancePaise=125050; int journeys=3000000; bool peak=true; char zone='M'; std::cout<<"sizeof(int)="<<sizeof(int)<<" sizeof(long long)="<<sizeof(long long)<<" sizeof(double)="<<sizeof(double)<<"\n"; std::cout<<"INT_MAX="<<INT_MAX<<"\n"; std::cout<<"Balance Rs "<<balancePaise/100.0<<", journeys "<<journeys<<", peak "<<peak<<", zone "<<zone<<"\n"; }
