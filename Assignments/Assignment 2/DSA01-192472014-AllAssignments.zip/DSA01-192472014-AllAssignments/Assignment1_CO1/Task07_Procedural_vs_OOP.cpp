#include <iostream>
long long fareForZone(int z){return z==1?1000:z==2?2000:z==3?3000:0;}
class FareTable { public: long long fare(int z)const{return fareForZone(z);} };
int main(){ int zone=3; std::cout<<"Procedural: "<<fareForZone(zone)<<" paise\n"; FareTable table; std::cout<<"OOP: "<<table.fare(zone)<<" paise\n"; }
