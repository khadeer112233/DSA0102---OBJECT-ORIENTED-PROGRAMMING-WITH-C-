#include <iostream>
int main(){ int a=9,b=4; double x=a/b; double y=static_cast<double>(a)/b; std::cout<<"Integer division stored in double: "<<x<<"\n"; std::cout<<"Floating division: "<<y<<"\n"; }
