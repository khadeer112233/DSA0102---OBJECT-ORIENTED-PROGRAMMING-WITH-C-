#include <iostream>
int main(){ int zones[]={1,2,3,4}; long long total=0; for(int z:zones){ int fare=0; switch(z){case 1:fare=10;break;case 2:fare=20;break;case 3:fare=30;break;default:std::cout<<"Invalid zone skipped\n";continue;} total+=fare; } std::cout<<"Total fare: Rs "<<total<<"\n"; }
