#include <iostream>
#include <string>
int main(){ std::string name; int zone,hour; std::cout<<"Enter passenger name: "; std::getline(std::cin,name); std::cout<<"Enter zone (1-3) and hour (0-23): "; if(!(std::cin>>zone>>hour)||zone<1||zone>3||hour<0||hour>23){std::cout<<"Invalid input\n";return 1;} std::cout<<"Passenger: "<<name<<"\nPeak: "<<(((hour>=8&&hour<10)||(hour>=17&&hour<20))?"Yes":"No")<<"\n"; }
