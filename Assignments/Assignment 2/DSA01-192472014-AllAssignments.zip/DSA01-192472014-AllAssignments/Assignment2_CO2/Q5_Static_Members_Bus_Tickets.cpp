#include <iostream>
class BusTicket{static int issued;static constexpr int capacity=4;int seat;public:BusTicket():seat(issued<capacity?++issued:0){}int getSeat()const{return seat;}static int count(){return issued;}};
int BusTicket::issued=0;
int main(){BusTicket t[6];for(auto&x:t)std::cout<<(x.getSeat()?std::to_string(x.getSeat()):"Waiting")<<'\n';std::cout<<"Issued: "<<BusTicket::count()<<'\n';}
