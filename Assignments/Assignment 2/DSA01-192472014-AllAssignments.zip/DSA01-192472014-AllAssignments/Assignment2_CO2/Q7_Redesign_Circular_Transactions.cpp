#include <iostream>
class RecentTransactions{long long data[50]{};int next=0,count=0;public:void add(long long x){data[next]=x;next=(next+1)%50;if(count<50)++count;}void print()const{for(int i=0;i<count;++i)std::cout<<data[(next-count+i+50)%50]<<' ';std::cout<<'\n';}};
int main(){RecentTransactions r;for(int i=1;i<=60;++i)r.add(i);r.print();}
