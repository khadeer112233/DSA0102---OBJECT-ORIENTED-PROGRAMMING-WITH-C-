#include <iostream>
struct Parcel{double kg;};
double charge(double kg,bool express=false,bool insured=false){return kg*50+(express?40:0)+(insured?25:0);}
double charge(int grams){return grams*0.05;}
double charge(Parcel p){return charge(p.kg,false,true);}
int main(){std::cout<<charge(2.0)<<'\n'<<charge(2.0,true)<<'\n'<<charge(2.0,true,true)<<'\n'<<charge(500)<<'\n'<<charge(Parcel{3.5})<<'\n';}
