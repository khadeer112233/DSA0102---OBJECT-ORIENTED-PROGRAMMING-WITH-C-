#include <iostream>
class Time{int h,m;public:Time(int hh,int mm):h(hh),m(mm){}friend bool earlier(const Time&,const Time&);friend int minutesBetween(const Time&,const Time&);};
inline bool earlier(const Time&a,const Time&b){return a.h*60+a.m<b.h*60+b.m;}
inline int minutesBetween(const Time&a,const Time&b){return (b.h*60+b.m)-(a.h*60+a.m);}
int main(){Time a(9,30),b(11,15);std::cout<<earlier(a,b)<<"\n"<<minutesBetween(a,b)<<" minutes\n";}
