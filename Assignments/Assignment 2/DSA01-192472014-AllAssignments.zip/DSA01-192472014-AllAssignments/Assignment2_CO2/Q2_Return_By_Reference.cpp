#include <iostream>
int& highest(int a[],int n){int k=0;for(int i=1;i<n;++i)if(a[i]>a[k])k=i;return a[k];}
int main(){int marks[]={70,91,84,88};highest(marks,4)+=2;for(int x:marks)std::cout<<x<<' ';std::cout<<"\n";}
