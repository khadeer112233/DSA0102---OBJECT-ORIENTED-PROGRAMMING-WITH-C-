#include <iostream>
#include <string>
class SavingsAccount{long long number,balance;int count=0;long long tx[10]{};void record(long long x){if(count<10)tx[count++]=x;else{for(int i=1;i<10;++i)tx[i-1]=tx[i];tx[9]=x;}}public:SavingsAccount(long long n,long long b):number(n),balance(b){}void deposit(long long x){if(x>0){balance+=x;record(x);}}bool withdraw(long long x){if(x<=0||x>balance)return false;balance-=x;record(-x);return true;}void miniStatement()const{std::cout<<"Account "<<number<<" balance "<<balance<<"\n";for(int i=0;i<count;++i)std::cout<<tx[i]<<' ';std::cout<<'\n';}};
int main(){SavingsAccount a(12345,1000);a.deposit(500);a.withdraw(200);a.deposit(100);a.miniStatement();}
